class RvmFormat:
    """RVM format"""
