class PlyFormat:
    """PLY format"""
